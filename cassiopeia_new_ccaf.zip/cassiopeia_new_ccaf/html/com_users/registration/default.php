<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_users
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

// Récupérer l'utilisateur connecté
$user = Factory::getUser();

// Vérifier si l'utilisateur est connecté ET est admin (super utilisateur)
if (!$user->id || !$user->authorise('core.admin'))
{
    echo '<div class="alert alert-warning">' . Text::_('Seuls les administrateurs peuvent accéder à ce formulaire.') . '</div>';
    return;
}

/** @var \Joomla\Component\Users\Site\View\Registration\HtmlView $this */
/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('keepalive')->useScript('form.validate');
?>

<div class="com-users-registration registration">
    <?php if ($this->params->get('show_page_heading')) : ?>
        <div class="page-header">
            <h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
        </div>
    <?php endif; ?>

    <form id="member-registration"
          action="<?php echo Route::_('index.php?option=com_users&task=registration.register'); ?>"
          method="post"
          class="com-users-registration__form form-validate"
          enctype="multipart/form-data">

        <?php foreach ($this->form->getFieldsets() as $fieldset) : ?>
            <?php if ($fieldset->name === 'captcha' && $this->captchaEnabled) continue; ?>
            <?php $fields = $this->form->getFieldset($fieldset->name); ?>
            <?php if (count($fields)) : ?>
                <fieldset>
                    <?php if (isset($fieldset->label)) : ?>
                        <legend><?php echo Text::_($fieldset->label); ?></legend>
                    <?php endif; ?>
                    <?php echo $this->form->renderFieldset($fieldset->name); ?>
                </fieldset>
            <?php endif; ?>
        <?php endforeach; ?>

        <?php if ($this->captchaEnabled) : ?>
            <?php echo $this->form->renderFieldset('captcha'); ?>
        <?php endif; ?>

        <div class="com-users-registration__submit control-group">
            <div class="controls">
                <button type="submit"
                        class="com-users-registration__register btn btn-primary validate">
                    <?php echo Text::_('JREGISTER'); ?>
                </button>
                <input type="hidden" name="option" value="com_users">
                <input type="hidden" name="task" value="registration.register">
            </div>
        </div>

        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
</div>
