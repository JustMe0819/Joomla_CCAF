<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;

$doc = Factory::getDocument();
$lang = Factory::getLanguage()->getTag();
$shortLang = strtolower(substr($lang, 0, 2));

// CSS personnalisé
$customCss = "
<style>
    .topbar-left {
        z-index: 20;
        position: relative;
    }

    .topbar-right {
        z-index: 10;
        position: relative;
    }

    .lang-switcher {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: flex-end;
        gap: 10px;
        padding: 5px;
    }

    .lang-switcher .quick-lang {
        text-decoration: none;
        font-size: 14px;
        padding: 6px 12px;
        border-radius: 6px;
        background-color: transparent;
        color: white;
        font-weight: 500;
        transition: background 0.3s, color 0.3s;
    }

    .lang-switcher .quick-lang:hover {
        background-color: #ffcd47;
        color: black;
    }
.lang-switcher .quick-lang.active {
        background-color: #ffcd47;
        color: black;
        font-weight: bold;
        text-decoration: underline;
    }

    .lang-switcher .dropdown-menu {
        background-color: #222;
        border: none;
        padding: 0;
        min-width: 160px;
    }

    .lang-switcher .dropdown-item {
        color: white;
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 14px;
        padding: 8px 12px;
    }

    .lang-switcher .dropdown-item:hover {
        background-color: #444;
    }

    .lang-switcher img.globe {
        width: 22px;
        height: auto;
        cursor: pointer;
    }

    @media (max-width: 576px) {
        .lang-switcher {
            justify-content: center;
        }

        .lang-switcher .quick-lang {
            font-size: 13px;
            padding: 5px 10px;
        }

        .lang-switcher .dropdown-menu {
            right: 0 !important;
            left: auto !important;
        }
    }
</style>
";
$doc->addCustomTag($customCss);
?>
<div class="lang-switcher topbar-right me-3">
    <!-- Langues principales -->
    <a href="/fr" class="quick-lang <?php echo ($shortLang === 'fr') ? 'active' : ''; ?>">FR</a>
    <a href="/en" class="quick-lang <?php echo ($shortLang === 'en') ? 'active' : ''; ?>">EN</a>
    <a href="/ar" class="quick-lang <?php echo ($shortLang === 'ar') ? 'active' : ''; ?>">AR</a>

    <!-- Dropdown globe -->
    <div class="dropdown">
        <img src="https://ccaf-chelles.fr/images/icones/internet%20blanc.png" class="globe" id="langDropdown" data-bs-toggle="dropdown" aria-expanded="false">
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="langDropdown">
            <li>
                <a class="dropdown-item" href="/de">
                    <img src="/images/Drapeaux/allemand.png" alt="DE" width="20"> Allemand
                </a>
            </li>
            <li>
                <a class="dropdown-item" href="/es">
                    <img src="/images/Drapeaux/espagnol.png" alt="ES" width="20"> Espagnol
                </a>
            </li>
            <li>
                <a class="dropdown-item" href="/pt">
                    <img src="/images/Drapeaux/portugais.png" alt="PT" width="20"> Portugais
                </a>
            </li>
            <li>
                <a class="dropdown-item" href="/zh">
                    <img src="/images/Drapeaux/chinois.png" alt="ZH" width="20"> Chinois
                </a>
            </li>
            <li>
                <a class="dropdown-item" href="/ja">
                    <img src="/images/Drapeaux/japonais.png" alt="JA" width="20"> Japonais
                </a>
            </li>
            <li>
                <a class="dropdown-item" href="/ru">
                    <img src="/images/Drapeaux/russe.png" alt="RU" width="20"> Russe
                </a>
            </li>
        </ul>
    </div>
</div>