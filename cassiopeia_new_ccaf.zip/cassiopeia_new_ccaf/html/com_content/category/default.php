<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Layout\LayoutHelper;

/** @var \Joomla\Component\Content\Site\View\Category\HtmlView $this */

$categoryId = $this->category->id;

if ($categoryId == 104) : ?>
    <div class="timeline">
        <?php foreach ($this->items as $index => $item) :
            // Choix côté gauche/droite
            $side = ($index % 2 === 0) ? 'left' : 'right';

            // Extraction année dans introtext : cherche <p>année</p>
            preg_match('/<p>(\d{4})<\/p>/', $item->introtext, $matches);
            $year = $matches[1] ?? '';

            // Enlever la balise année pour ne pas l'afficher deux fois
            $content = preg_replace('/<p>\d{4}<\/p>/', '', $item->introtext, 1);
            ?>
            <div class="timeline-item <?php echo $side; ?>">
                <?php if ($year) : ?>
                    <div class="year"><?php echo htmlspecialchars($year); ?></div>
                <?php endif; ?>
                <div class="content"><?php echo $content; ?></div>
            </div>
        <?php endforeach; ?>
    </div>
<?php else :
    // Rendu normal pour les autres catégories
    echo LayoutHelper::render('joomla.content.category_default', $this);
endif;
