<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.cassiopeia
 *
 * @copyright   (C) 2017 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

/** @var Joomla\CMS\Document\HtmlDocument $this */

$app   = Factory::getApplication();
$input = $app->getInput();
$wa    = $this->getWebAssetManager();

$doc = Factory::getDocument();

// Styles CSS
$doc->addStyleSheet('https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/user.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/menu.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/question-faq.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/chronologie.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/soliguide.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/contact.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/bulletins-info.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/benevolat-explication.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/benevolat-form.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/projet-associatif.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/actions.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/don-financier.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/don-financier-form.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/don-nature.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/conseil-admin.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/adresses.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/partenaires.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/plan-site.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/adherent.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/bandeau-defilant.css');
$doc->addStyleSheet(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/css/service_civique.css');

// Scripts JS
$doc->addScript('https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js');
$doc->addScript(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/js/modules/menu.js');
$doc->addScript(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/js/modules/question-faq.js');
$doc->addScript(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/js/modules/projet-associatif.js');
$doc->addScript(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/js/modules/actions.js');
$doc->addScript(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/js/modules/don-financier-form.js');
$doc->addScript(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/js/modules/benevolat-form.js');
$doc->addScript(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/js/modules/chiffres.js');
$doc->addScript(Uri::base() . 'media/templates/site/cassiopeia_new_ccaf/js/hide-media-ui.js');

// Browsers support SVG favicons
$this->addHeadLink(HTMLHelper::_('image', 'joomla-favicon.svg', '', [], true, 1), 'icon', 'rel', ['type' => 'image/svg+xml']);
$this->addHeadLink(HTMLHelper::_('image', 'favicon.ico', '', [], true, 1), 'alternate icon', 'rel', ['type' => 'image/vnd.microsoft.icon']);
$this->addHeadLink(HTMLHelper::_('image', 'joomla-favicon-pinned.svg', '', [], true, 1), 'mask-icon', 'rel', ['color' => '#000']);

// Detecting Active Variables
$option   = $input->getCmd('option', '');
$view     = $input->getCmd('view', '');
$layout   = $input->getCmd('layout', '');
$task     = $input->getCmd('task', '');
$itemid   = $input->getCmd('Itemid', '');
$sitename = htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');
$menu     = $app->getMenu()->getActive();
$pageclass = $menu !== null ? $menu->getParams()->get('pageclass_sfx', '') : '';

// Color Theme
$paramsColorName = $this->params->get('colorName', 'colors_standard');
$assetColorName  = 'theme.' . $paramsColorName;

// Use a font scheme if set in the template style options
$paramsFontScheme = $this->params->get('useFontScheme', false);
$fontStyles       = '';

if ($paramsFontScheme) {
    if (stripos($paramsFontScheme, 'https://') === 0) {
        $this->getPreloadManager()->preconnect('https://fonts.googleapis.com/', ['crossorigin' => 'anonymous']);
        $this->getPreloadManager()->preconnect('https://fonts.gstatic.com/', ['crossorigin' => 'anonymous']);
        $this->getPreloadManager()->preload($paramsFontScheme, ['as' => 'style', 'crossorigin' => 'anonymous']);
        $wa->registerAndUseStyle('fontscheme.current', $paramsFontScheme, [], ['rel' => 'lazy-stylesheet', 'crossorigin' => 'anonymous']);

        if (preg_match_all('/family=([^?:]*):/i', $paramsFontScheme, $matches) > 0) {
            $fontStyles = '--cassiopeia-font-family-body: "' . str_replace('+', ' ', $matches[1][0]) . '", sans-serif;
			--cassiopeia-font-family-headings: "' . str_replace('+', ' ', $matches[1][1] ?? $matches[1][0]) . '", sans-serif;
			--cassiopeia-font-weight-normal: 400;
			--cassiopeia-font-weight-headings: 700;';
        }
    } elseif ($paramsFontScheme === 'system') {
        $fontStylesBody    = $this->params->get('systemFontBody', '');
        $fontStylesHeading = $this->params->get('systemFontHeading', '');

        if ($fontStylesBody) {
            $fontStyles = '--cassiopeia-font-family-body: ' . $fontStylesBody . ';
            --cassiopeia-font-weight-normal: 400;';
        }
        if ($fontStylesHeading) {
            $fontStyles .= '--cassiopeia-font-family-headings: ' . $fontStylesHeading . ';
    		--cassiopeia-font-weight-headings: 700;';
        }
    } else {
        $wa->registerAndUseStyle('fontscheme.current', $paramsFontScheme, ['version' => 'auto'], ['rel' => 'lazy-stylesheet']);
        $this->getPreloadManager()->preload($wa->getAsset('style', 'fontscheme.current')->getUri() . '?' . $this->getMediaVersion(), ['as' => 'style']);
    }
}

// Enable assets
$wa->usePreset('template.cassiopeia.' . ($this->direction === 'rtl' ? 'rtl' : 'ltr'))
    ->useStyle('template.active.language')
    ->registerAndUseStyle($assetColorName, 'global/' . $paramsColorName . '.css')
    ->useStyle('template.user')
    ->useScript('template.user')
    ->addInlineStyle(":root {
		--hue: 214;
		--template-bg-light: #f0f4fb;
		--template-text-dark: #495057;
		--template-text-light: #ffffff;
		--template-link-color: var(--link-color);
		--template-special-color: #001B4C;
		$fontStyles
	}");

// Override 'template.active' asset to set correct ltr/rtl dependency
$wa->registerStyle('template.active', '', [], [], ['template.cassiopeia.' . ($this->direction === 'rtl' ? 'rtl' : 'ltr')]);

// Logo file or site title param
if ($this->params->get('logoFile')) {
    $logo = HTMLHelper::_('image', Uri::root(false) . htmlspecialchars($this->params->get('logoFile'), ENT_QUOTES), $sitename, ['loading' => 'eager', 'decoding' => 'async'], false, 0);
} elseif ($this->params->get('siteTitle')) {
    $logo = '<span title="' . $sitename . '">' . htmlspecialchars($this->params->get('siteTitle'), ENT_COMPAT, 'UTF-8') . '</span>';
} else {
    $logo = HTMLHelper::_('image', 'logo.svg', $sitename, ['class' => 'logo d-inline-block', 'loading' => 'eager', 'decoding' => 'async'], true, 0);
}

$hasClass = '';

if ($this->countModules('sidebar-left', true)) {
    $hasClass .= ' has-sidebar-left';
}

if ($this->countModules('sidebar-right', true)) {
    $hasClass .= ' has-sidebar-right';
}

// Container
$wrapper = $this->params->get('fluidContainer') ? 'wrapper-fluid' : 'wrapper-static';

$this->setMetaData('viewport', 'width=device-width, initial-scale=1');

$stickyHeader = $this->params->get('stickyHeader') ? 'position-sticky sticky-top' : '';

// Defer fontawesome for increased performance. Once the page is loaded javascript changes it to a stylesheet.
$wa->getAsset('style', 'fontawesome')->setAttribute('rel', 'lazy-stylesheet');
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">

<head>
    <jdoc:include type="metas" />
    <jdoc:include type="styles" />
    <jdoc:include type="scripts" />
</head>

<body class="site <?php echo $option
    . ' ' . $wrapper
    . ' view-' . $view
    . ($layout ? ' layout-' . $layout : ' no-layout')
    . ($task ? ' task-' . $task : ' no-task')
    . ($itemid ? ' itemid-' . $itemid : '')
    . ($pageclass ? ' ' . $pageclass : '')
    . $hasClass
    . ($this->direction == 'rtl' ? ' rtl' : '');
?>">
    <header class="header container-header full-width<?php echo $stickyHeader ? ' ' . $stickyHeader : ''; ?>">

       <?php if ( 
  $this->countModules('topbar-left') || 
  $this->countModules('topbar') || 
  $this->countModules('topbar-right')
) : ?> 
  <div style="display: flex; justify-content: space-between; align-items: center;"> 
    
    <div style="flex: 1; padding-left: 20px;"> 
      <jdoc:include type="modules" name="topbar-left" style="none" /> </div> 
    
    <div style="flex: 2; display: flex; justify-content: center;"> 
      <jdoc:include type="modules" name="topbar" style="none" /> </div> 
    
    <div style="flex: 1; text-align: right; padding-right: 20px;"> 
      <jdoc:include type="modules" name="topbar-right" style="none" /> </div>
  </div> 
  <?php endif; ?>

      <?php if ($this->countModules('top-banner')) : ?>
    <div id="top-banner-wrapper">
        <jdoc:include type="modules" name="top-banner" style="none" />
    </div>
<?php endif; ?>

<?php if (
  $this->countModules('below-top') ||
  $this->countModules('below-top-left') ||
  $this->countModules('below-top-right') ||
  true
) : ?>
  <div style="position: relative; width: 100%; background-color: white; overflow: hidden; padding: 25px 0; box-sizing: border-box;">

    <!-- Bande jaune inchangée -->
    <div style="position: absolute; top: 50%; left: 0; transform: translateY(-50%); height: 10px; width: 100%; background-color: #ffcd47; z-index: 0;"></div>

    <!-- Contenu principal -->
    <div style="
      position: relative;
      z-index: 1;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 10px 0 30px; /* Logo + proche du bord gauche */
      flex-wrap: nowrap;
    ">

      <!-- Logo (cliquable + ajusté) -->
      <div style="
        flex-shrink: 0;
        width: 180px; /* Réduit pour libérer de la place */
        display: flex;
        justify-content: flex-start;
      ">
        <a href="https://ccaf-chelles.fr/fr/accueil" style="display: inline-block;">
          <img src="https://ccaf-chelles.fr/images/logo/LOGO%20MAIL.jpg" alt="Logo"
               style="width: 100%; height: auto; border-radius: 10%; object-fit: cover;">
        </a>
      </div>

      <!-- Texte central -->
      <div style="flex-grow: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; height: 120px; text-align: center;">
        <div style="font-size: 36px; font-weight: bold; color: #1C916A; padding-bottom: 20px;">
          CCAF - Chelles
        </div>
        <div style="font-size: 25px; color: black; font-style: italic; padding-top: 4px; text-align: center;">
          "Fraternité en action"
        </div>
      </div>

      <!-- Boutons -->
      <div style="
        display: flex;
        flex-shrink: 0;
        gap: 0;
        margin-right: 20px; /* Réduit pour recentrer */
      ">
        <a href="index.php?option=com_content&view=category&layout=blog&id=29" style="text-decoration: none;">
          <button class="button_below"
            style="background-color: #f18997; color: white; width: 130px; height: 130px; border-radius: 130px; border: none; cursor: pointer; box-shadow: 5px 5px 15px 8px rgba(0, 0, 0, 0.25); margin-right: -20px; transition: transform 0.3s ease;"><strong>
            Être<br>bénévole</strong>
          </button>
        </a>
        <a href="index.php?option=com_content&view=category&layout=blog&id=32" style="text-decoration: none;">
          <button class="button_below"
            style="background-color: #1c916a; color: white; width: 130px; height: 130px; border-radius: 130px; border: none; cursor: pointer; box-shadow: 5px 5px 15px 8px rgba(0, 0, 0, 0.25); transition: transform 0.3s ease;"><strong>
            Faire un don</strong>
          </button>
        </a>
      </div>

    </div>

    <!-- Responsive ajustements -->
    <style>
      @media screen and (max-width: 600px) {
        /* Wrapper principal */
        div[style*="display: flex; justify-content: space-between;"] {
          flex-direction: column !important;
          align-items: center !important;
          gap: 10px;
        }

        /* Logo : taille réduite */
        img[alt="Logo"] {
          width: 160px !important;
          height: auto !important;
          object-fit: contain !important;
        }

        /* Masquer le bloc texte central */
        div[style*="flex-grow: 1; display: flex; flex-direction: column;"] {
          display: none !important;
        }

        /* Centrer les boutons */
        div[style*="display: flex; flex-shrink: 0; gap: 0;"] {
          justify-content: center !important;
          margin-right: 30px !important;
          gap: 15px !important;
          flex-wrap: wrap;
        }

        .button_below {
          width: 100px !important;
          height: 100px !important;
          font-size: 14px !important;
        }
      }
    </style>

  </div>
<?php endif; ?>




        <?php if ($this->params->get('brand', 1)) : ?>
            <div class="grid-child">
                <div class="navbar-brand">
                    <a class="brand-logo" href="<?php echo $this->baseurl; ?>/">
                        <?php echo $logo; ?>
                    </a>
                    <?php if ($this->params->get('siteDescription')) : ?>
                        <div class="site-description"><?php echo htmlspecialchars($this->params->get('siteDescription')); ?></div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($this->countModules('menu', true) || $this->countModules('search', true)) : ?>
    <div style="width: 100%; background-color: #EAFBF5 !important;">
        <div class="grid-child container-nav">
            <?php if ($this->countModules('menu', true)) : ?>
                <div class="custom-menu-wrapper" style="background: #EAFBF5 !important;">
                    <jdoc:include type="modules" name="menu" style="none" />
                </div>
            <?php endif; ?>
            <?php if ($this->countModules('search', true)) : ?>
                <div class="container-search">
                    <jdoc:include type="modules" name="search" style="none" />
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php endif; ?>

    </header>

    <div class="site-grid">
        <?php if ($this->countModules('banner', true)) : ?>
            <div class="container-banner full-width">
                <jdoc:include type="modules" name="banner" style="none" />
            </div>
        <?php endif; ?>

        <?php if ($this->countModules('top-a', true)) : ?>
            <div class="grid-child container-top-a">
                <jdoc:include type="modules" name="top-a" style="card" />
            </div>
        <?php endif; ?>

        <?php if ($this->countModules('top-b', true)) : ?>
            <div class="grid-child container-top-b">
                <jdoc:include type="modules" name="top-b" style="card" />
            </div>
        <?php endif; ?>

        <?php if ($this->countModules('sidebar-left', true)) : ?>
            <div class="grid-child container-sidebar-left">
                <jdoc:include type="modules" name="sidebar-left" style="card" />
            </div>
        <?php endif; ?>

        <div class="grid-child container-component">
            <jdoc:include type="modules" name="breadcrumbs" style="none" />
            <jdoc:include type="modules" name="main-top" style="card" />
            <jdoc:include type="message" />
            <main>
                <jdoc:include type="component" />
            </main>
            <jdoc:include type="modules" name="main-bottom" style="card" />
        </div>

        <?php if ($this->countModules('sidebar-right', true)) : ?>
            <div class="grid-child container-sidebar-right">
                <jdoc:include type="modules" name="sidebar-right" style="card" />
            </div>
        <?php endif; ?>

        <?php if ($this->countModules('bottom-a', true)) : ?>
            <div class="grid-child container-bottom-a">
                <jdoc:include type="modules" name="bottom-a" style="card" />
            </div>
        <?php endif; ?>

        <?php if ($this->countModules('bottom-b', true)) : ?>
            <div class="grid-child container-bottom-b">
                <jdoc:include type="modules" name="bottom-b" style="card" />
            </div>
        <?php endif; ?>
    </div>

<?php if ($this->countModules('footer_top', true)) : ?>
    <div class="footer-top full-width">
        <div class="container">
            <jdoc:include type="modules" name="footer_top" style="none" />
        </div>
    </div>
<?php endif; ?>
  
    <?php if ($this->countModules('footer', true)) : ?>
        <footer class="container-footer footer full-width">
            <div class="grid-child">
                <jdoc:include type="modules" name="footer" style="none" />
            </div>
        </footer>
    <?php endif; ?>


<?php if ($this->countModules('footer_bottom', true)) : ?>
    <div class="footer-bottom full-width">
        <div class="container">
            <jdoc:include type="modules" name="footer_bottom" style="none" />
        </div>
    </div>
<?php endif; ?>


    <?php if ($this->params->get('backTop') == 1) : ?>
        <a href="#top" id="back-top" class="back-to-top-link" aria-label="<?php echo Text::_('TPL_CASSIOPEIA_BACKTOTOP'); ?>">
            <span class="icon-arrow-up icon-fw" aria-hidden="true"></span>
        </a>
    <?php endif; ?>

    <jdoc:include type="modules" name="debug" style="none" />


</body>

</html>
