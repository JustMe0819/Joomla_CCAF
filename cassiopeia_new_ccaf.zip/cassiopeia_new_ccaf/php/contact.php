<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Fonction de nettoyage
  function clean($field) {
    return htmlspecialchars(trim($_POST[$field] ?? ''));
  }

  // Récupération des champs (noms mis à jour)
  $nom_famille = clean('nom_famille');
  $prenom = clean('prenom');
  $telephone = clean('telephone');
  $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
  $message = clean('message');

  // Vérification des champs
  if (!$nom_famille || !$prenom || !$telephone || !$email || !$message) {
    http_response_code(400);
    echo "Tous les champs sont obligatoires.";
    exit;
  }

  // Contenu de l'e-mail
    $to = 'assistante.ccaf@gmail.com';
  $subject = "Nouveau message depuis le formulaire de contact";
  $from = 'no-reply@ccaf-chelles.fr';

  $headers = "From: {$from}\r\n";
  $headers .= "Reply-To: {$email}\r\n";
  $headers .= "Return-Path: {$from}\r\n";
  $headers .= "MIME-Version: 1.0\r\n";
  $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

  $body = <<<EOD
Vous avez reçu un nouveau message via le site :

Nom       : $nom_famille
Prénom    : $prenom
Téléphone : $telephone
Email     : $email

Message :
$message
EOD;

  // Envoi
  if (mail($to, $subject, $body, $headers)) {
    echo "Message envoyé avec succès.";
    echo '<p><a href="/" style="display:inline-block;padding:10px 20px;background:#F18997;color:#fff;text-decoration:none;border-radius:5px;">Retour au site</a></p>';

  } else {
    http_response_code(500);
    echo "Erreur lors de l'envoi du message.";
  }
}
?>
