<?php
require(__DIR__ . '/../lib/fpdf/fpdf.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fonction pour formater proprement les disponibilités (tableau)
    function formatDispo($dispo) {
        $jours = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi'];
        $periodes = ['matin', 'après-midi'];
        $result = "";
        foreach ($jours as $jour) {
            if (!empty($dispo[$jour])) {
                $per = array_map('ucfirst', $dispo[$jour]);
                $result .= ucfirst($jour) . " : " . implode(", ", $per) . "\n";
            }
        }
        return $result;
    }

    // Création du PDF avec FPDF
    class PDF extends FPDF {
    function header() {
        $this->SetFont('Arial','B',14);
        $this->Cell(0,10,utf8_decode('Demande de bénévolat'),0,1,'C');  // <-- ici utf8_decode
        $this->Ln(5);
    }
    function footer() {
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,utf8_decode('Page '.$this->PageNo().'/{nb}'),0,0,'C'); // aussi ici
    }
}


    $pdf = new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Arial','',12);

    // On affiche les données POST dans le PDF
    foreach ($_POST as $key => $value) {
    if ($key === 'dispo' && is_array($value)) {
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(0,10, utf8_decode("Disponibilités :"), 0, 1);
        $pdf->SetFont('Arial','',12);
        $pdf->MultiCell(0,7, utf8_decode(formatDispo($value)));
    } else if (is_array($value)) {
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(0,10, utf8_decode(ucfirst($key)." :"), 0, 1);
        $pdf->SetFont('Arial','',12);
        $pdf->MultiCell(0,7, utf8_decode(implode(", ", $value)));
    } else {
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(0,10, utf8_decode(ucfirst($key)." :"), 0, 1);
        $pdf->SetFont('Arial','',12);
        $pdf->Cell(0,7, utf8_decode($value), 0, 1);
    }
    $pdf->Ln(3);
}


    // Générer PDF en string
    $pdfdoc = $pdf->Output('', 'S');

    // Préparation mail avec PDF en pièce jointe
    $to = "assistante.ccaf@gmail.com"; 
    $subject = "Nouvelle demande de bénévolat";
    $boundary = md5(time());

    $headers = "From: no-reply@ccaf-chelles.fr\r\n";
    $headers .= "Reply-To: no-reply@ccaf-chelles.fr\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"".$boundary."\"\r\n";

    $message = "--".$boundary."\r\n";
    $message .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $message .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $message .= "Une nouvelle demande de bénévolat a été reçue. Veuillez trouver le détail en pièce jointe.\r\n\r\n";

    $message .= "--".$boundary."\r\n";
    $message .= "Content-Type: application/pdf; name=\"demande_benevolat.pdf\"\r\n";
    $message .= "Content-Transfer-Encoding: base64\r\n";
    $message .= "Content-Disposition: attachment; filename=\"demande_benevolat.pdf\"\r\n\r\n";
    $message .= chunk_split(base64_encode($pdfdoc))."\r\n";
    $message .= "--".$boundary."--";

    if (mail($to, $subject, $message, $headers)) {
        echo '<p>Merci pour votre inscription, votre demande a bien été envoyée.</p>';
        echo '<p><a href="/" style="display:inline-block;padding:10px 20px;background:#F18997;color:#fff;text-decoration:none;border-radius:5px;">Retour au site</a></p>';
    } else {
        echo '<p>Erreur lors de l\'envoi du mail.</p>';
        echo '<p><a href="/" style="display:inline-block;padding:10px 20px;background:#F18997;color:#fff;text-decoration:none;border-radius:5px;">Retour au site</a></p>';
    }

} else {
    echo '<p>Méthode non autorisée</p>';
    echo '<p><a href="/" style="display:inline-block;padding:10px 20px;background:#F18997;color:#fff;text-decoration:none;border-radius:5px;">Retour au site</a></p>';
}
?>
